# 🐦 10 Nights with Sigeon Pex

![10 Nights with Sigeon Pex](assets/banner.png)

> **A completely normal security job.**

You are a night guard.  
**10 nights. Multiple locations. One very strange pigeon.**

And something is definitely wrong in the **Cosmo Zone**.

## 🎮 Play the game

**GitHub Pages:**  
https://wadim1488.github.io/10-nights-with-sigeon-pex/

The game is a standalone HTML project — no installation is required.

## 🌙 Game modes

| Mode | What to expect |
|---|---|
| 🟢 **NORMAL** | The standard survival experience. |
| 🔴 **HARD** | Broken cameras, more aggressive threats and hiding mechanics. |
| 🟣 **INSANE** | New cosmic threats, increased danger and rare events in the Cosmo Zone. |

## 📍 Locations

- 🚽 **TOILET**
- 🏄 **SURFING ZONE**
- 🍗 **KFC ZONE**
- 🌌 **COSMO ZONE**
- 📦 **WAREHOUSE**
- 👕 **CLOTHING STORE**
- 🚌 **BUS STOP**

## 👁️ Features

- Security camera system
- Multiple separate 2D locations
- Toilet camera
- Monster movement and random events
- Hiding spots in HARD mode
- 10-night survival system
- Achievements saved with `localStorage`
- Rare rabbit event: **`??? кролик ???`**
- Special cosmic Sigeon Pex in INSANE mode
- Atmospheric meme/horror presentation
- Subtle **made by wadim1488 (github)** watermark

## 🐇 Secret

Keep an eye on the **Cosmo Zone**.

Something unusual can appear there...

## 🏆 Achievements

- First Night
- Flush Machine
- Camera Addict
- Halfway There
- Hard Survivor
- Hide & Seek
- 10 Nights
- `??? кролик ???`

## 🛠️ Tech

Built as a lightweight browser game using:

- HTML
- CSS
- JavaScript
- HTML5 Canvas
- Local Storage

No backend or database is required.

## 🚀 Run locally

Clone or download the repository and open:

```text
index.html
```

in a modern browser.

For the easiest GitHub setup, put the game file at the repository root and name it:

```text
index.html
```

Then enable **GitHub Pages → Deploy from branch → main → / (root)**.

## 📁 Repository structure

```text
10-nights-with-sigeon-pex/
├── index.html
├── README.md
└── assets/
    ├── banner.png
    └── icon.png
```

## 📜 License

This project is provided as-is for the meme/horror game project.

If you reuse the project or its assets, please keep the original credit:

**made by wadim1488 (github)**

---

### 🐦 Survive the 10 nights.

**Don't trust the pigeon.**
